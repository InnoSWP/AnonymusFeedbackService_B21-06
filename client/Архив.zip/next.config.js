module.exports = {
    image: {
        domains: ["http://localhost:1337/"]
    }
    // reactStrictMode: false,
    // async rewrites() {
    //   return [
    //     {
    //       source: '/:path*',
    //       destination: 'https://localhost:5000/:path*',
    //     },
    //   ]
    // },
};
