const Loader = () => {
  return (
    <div className="ClockLoaderWrapper">
      <div className="ClockLoader"></div>
    </div>
  );
};

export default Loader;
