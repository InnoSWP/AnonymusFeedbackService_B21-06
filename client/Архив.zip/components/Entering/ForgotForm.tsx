const ForgotForm = () => {
    return <div>forgot</div>;
};

export default ForgotForm;
