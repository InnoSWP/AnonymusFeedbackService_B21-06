import React from "react";
import EnterSection from "../sections/EnterSection";

export default function Home() {
    return <EnterSection />;
}
