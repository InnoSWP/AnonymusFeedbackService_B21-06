import { TypedUseSelectorHook, useDispatch, useSelector } from "react-redux";
import { makeStore } from "../redux/store";

// export type AppDispatch = typeof makeStore.dispatch
// export const useAppDispatch = () => useDispatch<AppDispatch>()
